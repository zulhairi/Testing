<?php
session_start();

if (!isset($_SESSION["name"])) {
    header("Location: index.php");
    exit();
}

$isHod = $_SESSION["designation"] == "HOD";
$isExecutive = $_SESSION["designation"] == "Executive";
$isSeniorManager = $_SESSION["designation"] == "Senior Manager";
$isGeneralManager = $_SESSION["designation"] == "General Manager";
$isCeo = $_SESSION["designation"] == "CEO";
$isSeniorExecutive = $_SESSION["designation"] == "Senior Executive";
$isAccountsExecutive = $_SESSION["designation"] == "Accounts Executive";
?>  
<html>
  <head>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  <link rel="stylesheet" href="../css/style.css">
  <script src="script.js"></script>
</head>
<div class="sidebar">
  <a href="travel.php">Travelling Form</a>
  <a class="active" href="advance.php">Advance Form</a>
  <ul>
      <li>
        <a href="requestedadvance.php">Requested Advance</a>
      </li>
      <?php if ($isHod): ?>
      <li>
        <a href="hodapproval.php">HOD Approval</a>
      </li>
      <?php endif; ?>

      <?php if ($isExecutive): ?>
      <li>
        <a href="billing1approval.php">Billing 1 Approval</a>
      </li>
      <?php endif; ?>

      <?php if ($isSeniorManager): ?>
      <li>
        <a href="billing2approval.php">Billing 2 Approval</a>
      </li>
      <?php endif; ?>

      <?php if ($isGeneralManager): ?>
      <li>
        <a href="gmapproval.php">General Manager Approval</a>
      </li>
      <?php endif; ?>


      <?php if ($isCeo): ?> 
      <li>
        <a href="ceoapproval.php">CEO Approval</a>
      </li>
      <?php endif; ?>

      <?php if ($isAccountsExecutive): ?>
      <li>
        <a href="accountsapproval.php">Accounts Approval</a>
      </li>
      <?php endif; ?>

    </ul>
  <a href="../logout.php" class="logout-link" style = "background-color:#555; color:white;">
  <img src="../images/logout.png" alt="Exam" style="display:inline-block; vertical-align:middle; width:30px; height:30px;">  
  Logout</a>
</div>
<?php
// connect to the database
$servername = "localhost";
$username = "root";
$password = "1234";
$dbname = "eform";

$conn = new mysqli($servername, $username, $password, $dbname);

// check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// retrieve data from the database
$sql = "SELECT * FROM advance";
$result = $conn->query($sql);

// check if there is any data
if ($result->num_rows > 0) {
    // output data in a table
    echo "<div class='container'>";
    echo "<table id='table-data' class='table table-striped'>";
    echo "<thead id='table-header' style='background-color: #3a7bd5; color: white'>";
    echo "<tr>";
    echo "<th style='white-space: nowrap'>Name</th>";
    echo "<th style='white-space: nowrap'>Staff No.</th>";
    echo "<th>Designation</th>";
    echo "<th style='white-space: nowrap'>Date of Appointment</th>";
    echo "<th>Department</th>";
    echo "<th>Salary</th>";
    echo "<th style='white-space: nowrap'>Advance Required</th>";
    echo "<th style='white-space: nowrap'>Date Required</th>";
    echo "<th style='white-space: nowrap'>Nature of Works</th>";
    echo "<th style='white-space: nowrap'>Purpose of Advance</th>";
    echo "<th style='white-space: nowrap'>Previous Advance</th>";
    echo "<th>Reimbursable</th>";
    echo "<th>Actions</th>";
    echo "</tr>";
    echo "</thead>";
    echo "<tbody>";
  
    // output each row of data
    while($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<tr id='row-" . $row['id'] . "'>";
        echo "<td style='white-space: nowrap'>" . $row['name'] . "</td>";
        echo "<td style='white-space: nowrap'>" . $row['staff_no'] . "</td>";
        echo "<td style='white-space: nowrap'>" . $row['designation'] . "</td>";
        echo "<td style='white-space: nowrap'>" . $row['dateappointment'] . "</td>";
        echo "<td style='white-space: nowrap'>" . $row['department'] . "</td>";
        echo "<td style='white-space: nowrap'>" . $row['salary'] . "</td>";
        echo "<td style='white-space: nowrap'>" . $row['advancerequired'] . "</td>";
        echo "<td style='white-space: nowrap'>" . $row['daterequired'] . "</td>";
        echo "<td style='white-space: nowrap'>" . $row['nature'] . "</td>";
        echo "<td style='white-space: nowrap'>" . $row['purpose'] . "</td>";
        echo "<td style='white-space: nowrap'>" . $row['previousadvance'] . "</td>";
        echo "<td style='white-space: nowrap'>" . ($row['reimbursable'] == 1 ? "Yes" : "No") . "</td>";
        echo "<td style='white-space: nowrap'><div id='actions-" . $row['id'] . "' class='d-flex justify-content-end'>
        <button type='button' class='btn btn-success'
        onclick='approveRequest(" . $row['id'] . ")'>Approve</button>
        <button type='button' class='btn btn-danger' style = 'margin-left:5px;'
        onclick='rejectRequest(" . $row['id'] . ")'>Reject</button>
      </div></td>";
echo "</tr>";
      }
  
    echo "</tbody>";
    echo "</table>";
    echo "</div>";
  } else {
    echo "No data found.";
  }

// close connection
$conn->close();
?>

<script>
function approveRequest(id) {
   
    // Send the request to billing1approval.php with the id of the row to be approved
    window.location.href = "billing1approval.php?id=" + id + "&action=approve&redirect=hodapproval";

     // Hide the entire table and header
     document.getElementById("table-data").style.display = "none";
    document.getElementById("table-header").style.display = "none";

    // Remove the action buttons
    document.getElementById("actions-" + id).innerHTML = "";
}

function rejectRequest(id) {
    // Remove the action buttons
    document.getElementById("actions-" + id).innerHTML = "";

    // Send the request to billing1approval.php with the id of the row to be rejected
    window.location.href = "billing1approval.php?id=" + id + "&action=reject&redirect=hodapproval";
}

</script>