<?php
session_start();

if (!isset($_SESSION["name"])) {
    header("Location: index.php");
    exit();
}

$isHod = $_SESSION["designation"] == "HOD";
$isExecutive = $_SESSION["designation"] == "Executive";
$isSeniorManager = $_SESSION["designation"] == "Senior Manager";
$isGeneralManager = $_SESSION["designation"] == "General Manager";
$isCeo = $_SESSION["designation"] == "CEO";
$isSeniorExecutive = $_SESSION["designation"] == "Senior Executive";
$isAccountsExecutive = $_SESSION["designation"] == "Accounts Executive";
?>
<html>
  <head>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  <link rel="stylesheet" href="../css/style.css">
  <script src="script.js"></script>
</head>
<div class="sidebar">
  <a href="travel.php">Travelling Form</a>
  <a class="active" href="advance.php">Advance Form</a>
  <ul>
      <li>
        <a href="requestedadvance.php">Requested Advance</a>
      </li>
      <?php if ($isHod): ?>
      <li>
        <a href="hodapproval.php">HOD Approval</a>
      </li>
      <?php endif; ?>

      <?php if ($isExecutive): ?>
      <li>
        <a href="billing1approval.php">Billing 1 Approval</a>
      </li>
      <?php endif; ?>

      <?php if ($isSeniorManager): ?>
      <li>
        <a href="billing2approval.php">Billing 2 Approval</a>
      </li>
      <?php endif; ?>

      <?php if ($isGeneralManager): ?>
      <li>
        <a href="gmapproval.php">General Manager Approval</a>
      </li>
      <?php endif; ?>


      <?php if ($isCeo): ?> 
      <li>
        <a href="ceoapproval.php">CEO Approval</a>
      </li>
      <?php endif; ?>

      <?php if ($isAccountsExecutive): ?>
      <li>
        <a href="accountsapproval.php">Accounts Approval</a>
      </li>
      <?php endif; ?>

    </ul>
    <a href="../logout.php" class="logout-link" style = "background-color:#555; color:white;">
  <img src="../images/logout.png" alt="Exam" style="display:inline-block; vertical-align:middle; width:30px; height:30px;">  
  Logout</a>
</div>
<?php
// Connect to the database
$servername = "localhost";
$username = "root";
$password = "1234";
$dbname = "eform";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if (isset($_GET['action']) && isset($_GET['id']) && isset($_GET['redirect'])) {
  $action = $_GET['action'];
  $id = $_GET['id'];
  $redirect = $_GET['redirect'];

  // Update the HOD approval status based on the action
  if ($action == "approve") {
      $sql = "UPDATE advance SET finance_approval = 'Approved' WHERE id = $id";
  } elseif ($action == "reject") {
      $sql = "DELETE FROM advance WHERE id = $id";
  }

  // Execute the query
  if ($conn->query($sql) === TRUE) {
      echo "Record updated successfully";
  } else {
      echo "Error updating record: " . $conn->error;
  }

  // Redirect to the HOD approval page
  if ($redirect === "gmapproval") {
    header("Location: gmapproval.php");
    exit();
  }
}

  $sql = "SELECT * FROM advance WHERE finance_approval = 'Approved'";
$result = $conn->query($sql);

// Check if there is any data
if ($result->num_rows > 0) {
    // Output data in a table
    echo "<div class='container'>";
    echo "<table class='table table-striped'>";
    echo "<thead style='background-color: #3a7bd5; color: white'>";
    echo "<tr>";
    echo "<th style='white-space: nowrap'>Name</th>";
    echo "<th style='white-space: nowrap'>Staff No.</th>";
    echo "<th>Designation</th>";
    echo "<th style='white-space: nowrap'>Date of Appointment</th>";
    echo "<th>Department</th>";
    echo "<th>Salary</th>";
    echo "<th style='white-space: nowrap'>Advance Required</th>";
    echo "<th style='white-space: nowrap'>Date Required</th>";
    echo "<th style='white-space: nowrap'>Nature of Works</th>";
    echo "<th style='white-space: nowrap'>Purpose of Advance</th>";
    echo "<th style='white-space: nowrap'>Previous Advance</th>";
    echo "<th style='white-space: nowrap'>Reimbursable</th>";
    echo "<th style='white-space: nowrap'>HOD Status</th>";
    echo "<th style='white-space: nowrap'>Billing 1 Status</th>";
    echo "<th style='white-space: nowrap'>Billing 2 Status</th>";
    echo "<th style='white-space: nowrap'>Mr Yogan Status</th>";
    echo "<th>Actions</th>";
    echo "</tr>";
    echo "</thead>";
    echo "<tbody>";
  
    // Output each row of data
    while($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td style='white-space: nowrap'>" . $row['name'] . "</td>";
        echo "<td style='white-space: nowrap'>" . $row['staff_no'] . "</td>";
        echo "<td style='white-space: nowrap'>" . $row['designation'] . "</td>";
        echo "<td style='white-space: nowrap'>" . $row['dateappointment'] . "</td>";
        echo "<td style='white-space: nowrap'>" . $row['department'] . "</td>";
        echo "<td style='white-space: nowrap'>" . $row['salary'] . "</td>";
        echo "<td style='white-space: nowrap'>" . $row['advancerequired'] . "</td>";
        echo "<td style='white-space: nowrap'>" . $row['daterequired'] . "</td>";
        echo "<td style='white-space: nowrap'>" . $row['nature'] . "</td>";
        echo "<td style='white-space: nowrap'>" . $row['purpose'] . "</td>";
        echo "<td style='white-space: nowrap'>" . $row['previousadvance'] . "</td>";
        echo "<td style='white-space: nowrap'>" . ($row['reimbursable'] == 1 ? "Yes" : "No") . "</td>";
        echo "<td style='white-space: nowrap'>" . $row['hod_approval'] . "</td>";
        echo "<td style='white-space: nowrap'>" . $row['billing_approval'] . "</td>";
        echo "<td style='white-space: nowrap'>" . $row['billing2_approval'] . "</td>";
        echo "<td style='white-space: nowrap'>" . $row['finance_approval'] . "</td>";
        echo "<td style='white-space: nowrap'><div id='actions-" . $row['id'] . "' class='d-flex justify-content-end'>
        <button type='button' class='btn btn-success'
        onclick='approveRequest(" . $row['id'] . ")'>Approve</button>
        <button type='button' class='btn btn-danger' style = 'margin-left:5px;'
        onclick='rejectRequest(" . $row['id'] . ")'>Reject</button>
      </div></td>";
        echo "</tr>";
    }
  
    echo "</tbody>";
    echo "</table>";
    echo "</div>";
} else {
  header("gmapproval.php");
}

// Close connection
$conn->close();
?>

<script>
function approveRequest(id) {

    // Send the request to accountsapproval.php with the id of the row to be approved
    window.location.href = "accountsapproval.php?id=" + id + "&action=approve&redirect=ceoapproval";
}

function rejectRequest(id) {
    // Remove the action buttons
    document.getElementById("actions-" + id).innerHTML = "";

    // Send the request to accountsapproval.php with the id of the row to be rejected
    window.location.href = "accountsapproval.php?id=" + id + "&action=reject&redirect=ceoapproval";
}

</script>