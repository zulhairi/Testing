<?php
session_start();

if (!isset($_SESSION["name"])) {
    header("Location: index.php");
    exit();
}

$isHod = $_SESSION["designation"] == "HOD";
$isExecutive = $_SESSION["designation"] == "Executive";
$isSeniorManager = $_SESSION["designation"] == "Senior Manager";
$isGeneralManager = $_SESSION["designation"] == "General Manager";
$isCeo = $_SESSION["designation"] == "CEO";
$isSeniorExecutive = $_SESSION["designation"] == "Senior Executive";
$isAccountsExecutive = $_SESSION["designation"] == "Accounts Executive";
?>
<!DOCTYPE html>
<html>
<head>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  <link rel="stylesheet" href="../css/style.css">
  <script src="script.js"></script>
</head>
<body>
<div class="sidebar">
  <div class="sidebar-links">
    <a href="../travelling/travel.php">Travelling Form</a>
    <a class="active" href="../advance/advance.php">Advance Form</a>
    <ul>
      <li>
        <a href="requestedadvance.php">Requested Advance</a>
      </li>
      <?php if ($isHod): ?>
      <li>
        <a href="hodapproval.php">HOD Approval</a>
      </li>
      <?php endif; ?>

      <?php if ($isExecutive): ?>
      <li>
        <a href="billing1approval.php">Billing 1 Approval</a>
      </li>
      <?php endif; ?>

      <?php if ($isSeniorManager): ?>
      <li>
        <a href="billing2approval.php">Billing 2 Approval</a>
      </li>
      <?php endif; ?>

      <?php if ($isGeneralManager): ?>
      <li>
        <a href="gmapproval.php">General Manager Approval</a>
      </li>
      <?php endif; ?>


      <?php if ($isCeo): ?> 
      <li>
        <a href="ceoapproval.php ">CEO Approval</a>
      </li>
      <?php endif; ?>

      <?php if ($isAccountsExecutive): ?>
      <li>
        <a href="accountsapproval.php">Accounts Approval</a>
      </li>
      <?php endif; ?>

    </ul>
    <a href="../entertainment/entertainment.php">Entertainment Form</a>
    <a href="../ot/overtime.php">Overtime Form</a>
  <a href="../meal/mealallowance.php">OT Meal Form</a>
  <a href="../creditcard/creditcard.php">Credit Card Form</a>
  </div>
  <a href="../logout.php" class="logout-link" style = "background-color:#555; color:white;">
  <img src="../images/logout.png" alt="Exam" style="display:inline-block; vertical-align:middle; width:30px; height:30px;">  
  Logout</a>
</div>
<div class="form-container">
  <div class="form-number-container">
  </div>
    <h2>MINCONSULT SDN BHD</h2>
    <h3><strong><center>Application for Advance</center></strong></h3>
    <form id="advance-form" action="store_advance.php" method="POST" enctype="multipart/form-data">
    <div class="form-row">
      <div class="form-group">
        
      <?php

      if (!isset($_SESSION["name"])) {
          header("Location: index.php");
          exit();
      }

      $name = $_SESSION["name"];
      $staff_no = $_SESSION["staff_no"];
      $designation = $_SESSION["designation"];
      $department = $_SESSION["department"];
      ?>

      <label for="name">Name:</label>
        <input type="text" id="name" name="name" value="<?php echo $name; ?>" readonly="readonly">
        <div>
        </div>
      </div> 
      <div class="form-group">
        <label for="staff">Staff No:</label>
        <input type="text" id="staff" name="staff" value="<?php echo $staff_no; ?>" readonly="readonly">
      </div>
    </div>
    <div class="form-row">
      <div class="form-group">
      <label for="designation">Designation:</label>
        <input type="text" id="designation" name="designation" value="<?php echo $designation; ?>" readonly="readonly">
        <div>
        </div> 
      </div> 
      <div class="form-group">
        <label for="appointment">Date of Appointment:</label>
        <input type="date" id="appointment" name="appointment" required>
      </div>
    </div>
    <div class="form-row">
      <div class="form-group">
      <label for="department">Department:</label>
        <input type="text" id="department" name="department" value="<?php echo $department; ?>" readonly="readonly">
        <div>
        </div>
      </div> 
      <div class="form-group">
        <label for="month">Salary per month (RM):</label>
        <input type="number" id="salary" name="salary" required>
      </div>
    </div>
    <br>
    <div class = "full-blue"></div>
  <br>
        <div class="form-row">
      <div class="form-group">
        <label for="advancerequired">Advance Required:</label>
        <input type="number" id="advancerequired" name="advancerequired" required>
        <div>
        </div>
    </div>
    <div class="form-group">
        <label for="advanceDate">When Required:</label>
        <input type="date" id="advanceDate" name="advanceDate" required>
      </div>
      </div>

      <div class="form-group">
        <label for="place">Project / Nature of Works:</label>
        <textarea id="nature-of-works" name="nature-of-works" rows="3" required></textarea>
      </div>

      <div class="form-group">
        <label for="place">Purpose of Advance:</label>
        <textarea id="purpose-of-advance" name="purpose-of-advance" rows="3" required></textarea>
      </div>

      <form id="travelling-form">
        <div class="form-row">
      <div class="form-group">
        <label for="previousAdvance">Previous Advances In Hand (RM):</label>
        <input type="number" id="previousAdvance" name="previousAdvance" required>
        <div>
        </div>
    </div>
    <div class="form-group">
        <label for="reimbursable">Reimbursable or not:</label>
        <select id ="reimbursable" name = "reimbursable" required>
            <option value="0">Please select</option>
          <option value="1">Yes</option>
          <option value="2">No</option>
        </select>
      </div>
      </div>
      <div class="form-group">
  <label>
    <input type="checkbox" name="verification" required>
    I hereby certify that all information above is correct
  </label>
</div>
<div class="form-group">
  <label for="attachment">Supporting attachement:</label>
  <input type="file" id="attachment" name="attachment" required>
</div>
   <hr>
    <div class="form-buttons">
        <button type="submit">Submit</button>
      </div>
      </form>
  </div>
  <script src="script.js"></script>
  </html>
</body>
