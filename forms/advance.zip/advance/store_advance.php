<?php
// connect to the database
$servername = "localhost";
$username = "root";
$password = "1234";
$dbname = "eform";

$conn = new mysqli($servername, $username, $password, $dbname);

// check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// retrieve form data
$name = isset($_POST['name']) ? $_POST['name'] : '';
$staff = isset($_POST['staff']) ? $_POST['staff'] : '';
$designation = isset($_POST['designation']) ? $_POST['designation'] : '';
$dateappointment = isset($_POST['appointment']) ? $_POST['appointment'] : date('Y-m-d');
$department = isset($_POST['department']) ? $_POST['department'] : '';
$salary = isset($_POST['salary']) ? $_POST['salary'] : '';
$advancerequired = isset($_POST['advancerequired']) ? $_POST['advancerequired'] : '';
$daterequired = isset($_POST['advanceDate']) ? $_POST['advanceDate'] : '';
$nature = isset($_POST['nature-of-works']) ? $_POST['nature-of-works'] : '';
$purpose = isset($_POST['purpose-of-advance']) ? $_POST['purpose-of-advance'] : '';
$previousadvance = isset($_POST['previousAdvance']) ? $_POST['previousAdvance'] : '';
$reimbursable = isset($_POST['reimbursable']) ? $_POST['reimbursable'] : '';

// prepare and execute SQL query
$stmt = $conn->prepare("INSERT INTO advance (name, staff_no, designation, dateappointment, department, salary, advancerequired, daterequired, nature, purpose, previousadvance, reimbursable) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
$stmt->bind_param("ssssssssssss", $name, $staff, $designation, $dateappointment, $department, $salary, $advancerequired, $daterequired, $nature, $purpose, $previousadvance, $reimbursable);

if ($stmt->execute() === TRUE) {
    header("Location: advance.php");
} else {
  echo "Error: " . $stmt->error;
}

// close statement and connection
$stmt->close();
$conn->close();
?>